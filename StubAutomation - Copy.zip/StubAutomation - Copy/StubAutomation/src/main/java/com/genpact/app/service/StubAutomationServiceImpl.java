package com.genpact.app.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genpact.app.dao.StubAutomationDao;
import com.genpact.app.model.SignUpModel;

@Service
public class StubAutomationServiceImpl implements StubAutomationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(StubAutomationServiceImpl.class);
	
	@Autowired
	StubAutomationDao stubAutomationDao;

	@Override
	public String signUp(SignUpModel signUpModel) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String signIn(SignUpModel signInModel) {
		// TODO Auto-generated method stub
		return null;
	}
}
