package com.genpact.app.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.genpact.app.model.SignUpModel;

public interface StubAutomationApi {
	
	@PostMapping(value="/signUp", produces= {"application/json"}, consumes= {"application/json"})
	public ResponseEntity<String> signUp(@RequestBody SignUpModel signUpModel);
	
	@PostMapping(value="/signIn", produces= {"application/json"}, consumes= {"application/json"})
	public String signIn(@RequestBody SignUpModel signInModel);
	
	
}
