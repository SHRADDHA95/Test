package com.genpact.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.genpact.app.entity.UserAuthEntity;

@Repository
public interface StubAutomationDao extends JpaRepository<UserAuthEntity, String>{
	
}
