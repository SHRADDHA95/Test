package com.genpact.app.service;

import com.genpact.app.model.SignUpModel;

public interface StubAutomationService {
	
	String signUp(SignUpModel signUpModel);

	String signIn(SignUpModel signInModel);
	
}
