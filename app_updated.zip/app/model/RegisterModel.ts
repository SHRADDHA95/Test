export class Register {
    userId: number;
    title: String;
    body:String;
    id : number;
}
