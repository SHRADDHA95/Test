
import { Component, OnInit } from '@angular/core'
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms'
import {Register} from '../model/RegisterModel'
import {RegisterService} from '../service/register.service'

@Component({
  selector: 'register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  hasError: boolean = false;
  message: String;
  id: number;
  register : Register = {} as Register
  constructor( private registerService : RegisterService,
    private fb: FormBuilder,
    ) { }

  ngOnInit() {
    this.register.userId = 777
    this.register.title = 'Test Title'
    this.register.body = 'request body'
  }

  //Service to post data
  registerUser() {


        this.registerService.register(this.register)
         .subscribe(data => {
            console.log(JSON.stringify(data));


         }, error => {
           this.hasError = true;
           this.message = error.error.message;
         })
     }
//ends


showConfigResponse() {
  this.registerService.getConfigResponse()
    // resp is of type `HttpResponse<Config>`
    .subscribe(resp => {
      // display its headers
      const keys = resp.headers.keys();
      this.headers = keys.map(key =>
        `${key}: ${resp.headers.get(key)}`);

      // access the body directly, which is typed as `Config`.
      console.log(resp.body);
      //this.config = { ... resp.body };
    });
}

}
