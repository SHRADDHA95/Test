import { Register } from './../model/RegisterModel';
import { element } from 'protractor';
import { environment } from './../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class RegisterService {

    constructor(private http: HttpClient) { }

    public register(register: Register):Observable<Register> {
      console.log('in register service, in register method');
            let body = JSON.stringify(register)
            return this.http.post<Register>('http://jsonplaceholder.typicode.com/posts', body)
    }

  public getData(): Observable<HttpResponse<Config>> {
     return this.http.get('jsonplaceholder.typicode.com/posts');
}

getConfigResponse(): Observable<HttpResponse<Register>> {
  console.log('in register service, getConfigResponse() method');
  return this.http.get<Register>(
    'http://jsonplaceholder.typicode.com/posts?userId=1', { observe: 'response' });
}

}
