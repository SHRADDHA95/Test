import { Register } from './../model/RegisterModel';
import { element } from 'protractor';
import { environment } from './../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class RegisterService {

    constructor(private http: HttpClient) { }

    public register(register: Register) {
        return this.http.post('http://jsonplaceholder.typicode.com/posts', register);
        //alert("Inside Http service");
     
    }

    
}