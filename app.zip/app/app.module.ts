import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';


import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { RegisterService } from './service/register.service';



@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    
  ],
  

  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [
 
    { provide: 'registerService', useClass: RegisterService },
  
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
