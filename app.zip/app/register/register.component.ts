
import { Router } from '@angular/router';
import {Injectable} from '@angular/core'
import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { error } from 'util';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Component({
  selector: 'register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  myForm: FormGroup;
  showOtpInput: boolean = false;
  hasError: boolean = false;
  message: String;
  id: number;
  heroesUrl:String;
  constructor(@Inject("registerService") private registerService,
    private fb: FormBuilder,
    ) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      id: null,
      username: new FormControl('', Validators.required),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    })
  }

 register(myForm: FormGroup) {
    console.log(myForm)
    if (myForm.valid) {
      this.registerService.register(myForm.value)
        .subscribe(data => {
           console.log(myForm.value);
        }, error => {
          this.hasError = true;
          this.message = error.error.message;
        })
    }

  }
  get username() { return this.myForm.controls.username; }
  get password() { return this.myForm.controls.password; }
  get email() { return this.myForm.controls.email; }



}
