export class Register {
    userName: String;
    password: String;
}
